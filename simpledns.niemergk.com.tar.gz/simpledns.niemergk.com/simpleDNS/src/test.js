const whois = require('whois-json')

const ourNS = ['ns.inmotionhosting.com', 'ns1.inmotionhosting.com', 'ns2.inmotionhosting.com']

// const result = async () => {
//     const data = await whois('niemergk.com')
//     const nsArray = data.nameServer.split(' ')

//     const isUsingOurNS = nsArray.some(ourNS)
//     console.log(isUsingOurNS)
// } 

const result = async (domain) => {
    const data = await whois(domain)
    const nsArray = data.nameServer.split(' ')
    console.log(nsArray)
    for(var i = 0; i < nsArray.length; i++) {
        if(nsArray[i] != ourNS[i]) {
            console.log('Not our name servers')
        } else {
            console.log('Using our name servers')
        }
    }
}

console.log(result('niemergk.com'))